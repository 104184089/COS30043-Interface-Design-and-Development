const Dashboard = {
    template: `
        <h1>Dashboard</h1>
    `
};