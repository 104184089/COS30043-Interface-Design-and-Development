const Login = {
    data() {
        return {
            username: '',
            password: '',
            error: ''
        }
    },
    methods: {
        async handleSubmit(event) {
            event.preventDefault();

            // 
            try {
                const response = await fetch('resources/api_user.php/', {
                    method: 'POST', 
                    body: JSON.stringify({
                        username: this.username,
                        password: this.password
                    }),
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
    
                const data = await response.json();
    
                if (data == null) {
                    this.error = 'Invalid credentials'; 
                } else {
                    // logged in success
                    this.$emit('authenticated', true); // options api -> use emit()
                    // redirect user to dashboard
                    this.$router.replace('dashboard');
                }
            } catch (e) {
                this.error = e;
            }
        }
    },
    template: `
        <h1>Login</h1>

        <p>{{error}}</p>

        <form @submit="handleSubmit">
            <div>
                <label>Username</label>
                <input v-model="username">
            </div>
            <div>
                <label>Password</label>
                <input v-model="password">
            </div>
            <button type="submit">Login</button>
        </form>
    `
};