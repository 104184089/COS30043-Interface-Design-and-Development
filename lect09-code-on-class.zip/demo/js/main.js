const app = Vue.createApp({
    data() {
        return {
            message: 'Hello Vue',
            authenticated: false,
        }
    },
    mounted() {
        if (!this.authenticated) {
            // redirect user to login
            this.$router.replace('login');
        }
    },
    methods: {
        setAuthenticated(status) {
            this.authenticated = status;
        },
        logout() {
            this.authenticated = false;
        }
    },
    template: `
        {{message}}

        <app-nav v-if="authenticated" :setAuthenticated="setAuthenticated"></app-nav>

        <router-view @authenticated="setAuthenticated"></router-view>
    `
});

app.component('app-nav', {
    props: ['setAuthenticated'],
    methods: {
        logout() {
            this.setAuthenticated(false);
        }
    },
    template: `<nav>
        <router-link to="/dashboard">Dashboard</router-link>
        | 
        <router-link to="/logout" @click="logout">Logout</router-link>
    </nav>
    `
});

const router = VueRouter.createRouter({
    history: VueRouter.createWebHashHistory(),
    routes: [
        {path: '/dashboard', component: Dashboard},
        {path: '/login', component: Login, name: "login"},
    ]
});

app.use(router);

app.mount('#app');