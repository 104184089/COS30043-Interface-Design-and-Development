Vue.createApp({
    data() {
        return {
            userGuess: '',
            number: Math.floor(Math.random() * 100) + 1,
            alert: "Start Guessing...",
        }
    },
    methods: {
        checkGuess() {
            if (this.userGuess == this.number) {
                this.alert = "You got it!"
            } else if (this.userGuess > this.number) {
                this.alert = "Guess lower"
            } else {
                this.alert = "Guess higher"
            }
        },
        giveUp() {
            this.alert = "The number is " + this.number + ". Better luck next time!"
        },
        startOver() {
            this.number = Math.floor(Math.random() * 100) + 1
            this.alert = "Start Guessing..."
            this.userGuess = 0
        }
    }
}).mount('#app');